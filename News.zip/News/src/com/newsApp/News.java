package com.newsApp;

public interface News {
	
	public String getNews();
	
	public String getDailyTemperature();

}
