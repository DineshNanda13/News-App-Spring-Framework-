package com.newsApp;

public interface Temperature {
	
	public String getTemperature();
	
}
